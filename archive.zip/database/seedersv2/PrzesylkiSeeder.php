<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use App\Models\Przesylki;

class PrzesylkiSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        // Wstawiamy dane do tabeli 'przesyłki` jesli chcemy wstawic dane.
    }
}
