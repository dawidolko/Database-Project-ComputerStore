<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Relations\Pivot;

class ProductsCategories extends Pivot
{
    // protected $table = 'product categories'; 
    // protected $fillable = ['PRODUCTS_ID', 'CATEGORY_ID'];

}
