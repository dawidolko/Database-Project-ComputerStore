<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Relations\Pivot;

class OrdersProducts extends Pivot
{
    // protected $table = 'orders_products';
     // public $timestamps = false;
    
     // protected $fillable = ['ORDERS_ID', 'PRODUCTS_ID'];

}
