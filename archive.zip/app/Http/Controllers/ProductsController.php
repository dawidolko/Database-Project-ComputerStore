<?php

namespace App\Http\Controllers;

use App\Models\Produkty;
use Illuminate\Http\Request;

class ProduktyController extends Controller
{
    // public function index()
    // {
    //     $produkty = Produkty::with(['zdjecia', 'kategorie'])->get();
    //     return view('index', ['produkty' => $produkty]);
    // }
}
